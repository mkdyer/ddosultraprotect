module google.golang.org/grpc/security/advancedtls

go 1.26.0

require (
	github.com/hashicorp/golang-lru v0.5.4
	golang.org/x/crypto v0.57.0
	google.golang.org/grpc v1.85.0
	google.golang.org/grpc/examples v0.0.0-20230120001647-bc9728f98bdc
)

require (
	github.com/golang/protobuf v1.5.4 // indirect
	golang.org/x/net v0.60.0 // indirect
	golang.org/x/sys v0.48.0 // indirect
	golang.org/x/text v0.42.0 // indirect
	google.golang.org/genproto v0.0.0-20230110181048-76db0878b65f // indirect
	google.golang.org/protobuf v1.36.12 // indirect
)

replace google.golang.org/grpc => ../../

replace google.golang.org/grpc/examples => ../../examples
