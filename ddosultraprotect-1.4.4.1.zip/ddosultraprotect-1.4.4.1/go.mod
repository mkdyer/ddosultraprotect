module google.golang.org/grpc

go 1.24.6

require (
	github.com/cespare/xxhash/v2 v2.3.0
	github.com/cncf/udpa/go v0.0.0-20201120205902-5459f2c99403
	github.com/cncf/xds/go v0.0.0-20260202195803-dba9d589def2
	github.com/envoyproxy/go-control-plane v0.9.9-0.20210512163311-63b5d3c536b0
	github.com/golang/glog v0.0.0-20160126235308-23def4e6c14b
	github.com/golang/protobuf v1.5.2
	github.com/google/go-cmp v0.7.0
	github.com/google/uuid v1.1.2
	golang.org/x/net v0.42.0
	golang.org/x/oauth2 v0.0.0-20200107190931-bf48bf16ab8d
	golang.org/x/sys v0.34.0
	gonum.org/v1/gonum v0.17.0
	google.golang.org/genproto v0.0.0-20211102202547-e9cf271f7f2c
	google.golang.org/protobuf v1.36.12
)

require (
	cel.dev/expr v0.25.1 // indirect
	cloud.google.com/go v0.34.0 // indirect
	github.com/census-instrumentation/opencensus-proto v0.2.1 // indirect
	github.com/envoyproxy/protoc-gen-validate v1.3.0 // indirect
	golang.org/x/text v0.27.0 // indirect
	golang.org/x/tools v0.34.0 // indirect
	google.golang.org/appengine v1.4.0 // indirect
)

replace google.golang.org/grpc v1.85.0 => google.golang.org/grpc v1.62.1
